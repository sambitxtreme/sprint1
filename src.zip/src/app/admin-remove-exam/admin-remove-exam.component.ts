import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin-remove-exam',
  templateUrl: './admin-remove-exam.component.html',
  styleUrls: ['./admin-remove-exam.component.css']
})
export class AdminRemoveExamComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
