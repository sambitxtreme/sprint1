export class ResponseClass {
    responseMessage: String;
    responseCode : number;
    responseObject : any;
}
