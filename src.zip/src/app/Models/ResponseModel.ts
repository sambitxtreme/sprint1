export class ResponseClass {
    constructor(
        responseMessage: String,
        responseCode : number,
        responseObject : any
    ){}
}
