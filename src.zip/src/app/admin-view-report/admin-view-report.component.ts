import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin-view-report',
  templateUrl: './admin-view-report.component.html',
  styleUrls: ['./admin-view-report.component.css']
})
export class AdminViewReportComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
