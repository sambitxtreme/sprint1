import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-select-subject',
  templateUrl: './select-subject.component.html',
  styleUrls: ['./select-subject.component.css']
})
export class SelectSubjectComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
