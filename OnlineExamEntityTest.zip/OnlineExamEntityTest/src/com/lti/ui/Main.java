package com.lti.ui;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import com.lti.model.AdminLogin;
import com.lti.model.CacheTable;
import com.lti.model.Exam;
import com.lti.model.Questions;
import com.lti.model.User;
import com.lti.model.UserLogin;
import com.lti.model.UserScore;
import com.lti.utils.JpaUtils;

public class Main {
	//read all table values
	public static String GET_ALL_ADMIN_EXAM="Select  a From AdminExam a";
	public static String GET_ALL_ADMIN_LOGIN="Select  a From AdminLogin a";
	public static String GET_ALL_CACHE_TABLE="Select  c From CacheTable c";
	public static String GET_ALL_EXAM="Select e From Exam e";
	public static String GET_ALL_QUESTIONS="Select q From Questions q";
	public static String GET_ALL_USER="Select u From User u";
	public static String GET_ALL_USER_LOGIN="Select u From UserLogin u";
	public static String GET_ALL_USER_SCORE="Select u From UserScore u";
	
	//insert operation
	public static String GET_ADMIN_BY_ADMIN_LOGIN="insert into AdminLogin(adminId,adminName,adminPassword) values(?,?,?) ";
//	public static String GET_ADMIN_BY_ADMIN_LOGIN="insert into Admin_Login(admin_Id,admin_Name,Password) values(?,?,?) ";
	public static String GET_USER_BY_USER_REGISTRATION="insert into User(userId,firstName,lastName,email,mobileNumber,dateOfBirth,city,state,qualification,yearOfCompletion) values(?,?,?,?,?,?,?,?,?,?) ";
	public static String GET_EXAM_DETAILS="insert into Exam(examId,examName,examDate,startTime,endTime) values(?,?,?,?,?) ";
	public static String GET_QUESTION_DETAILS="insert into Questions(questionId,examId,question,option1,option2,option3,option4,correctAnswer) values(?,?,?,?,?,?,?,?)";
	public static String GET_USER_SCORE_DETAILS="insert into UserScore(userScoreId,scorePerAttempt,dateOfExam,timeTaken) values(?,?,?,?) ";
	public static String GET_CACHE_TABLE_DETAILS="insert into CacheTable(cacheId,ansSelected) values(?,?) ";
	static EntityManager entityManager;
	
	//delete
		 public static String DELETE_ALL_FROM_USER="DELETE FROM User u WHERE u.userId=:user";
		public static String DELETE_ALL_FROM_USERLOGIN="DELETE FROM UserLogin u WHERE u.userId=:userId";
		public static String DELETE_ALL_FROM_QUESTIONS="DELETE FROM Questions q WHERE q.questionId=:questionId";
		public static String DELETE_ALL_FROM_EXAM="DELETE FROM Exam e WHERE e.examId=:examId";
		public static String DELETE_ALL_FROM_ADMINLOGIN="DELETE FROM AdminLogin a WHERE a.adminId=:adminId";
		public static String DELETE_ALL_FROM_ADMINEXAM="DELETE FROM AdminExam a WHERE a.adminId=:adminId";
		public static String DELETE_ALL_FROM_USERSCORE="DELETE FROM USERSCORE u WHERE u.userScore_Id=:userScore_id";
		public static String DELETE_ALL_FROM_CACHETABLE="DELETE FROM CacheTable c WHERE c.cacheId=:cacheId";
		//update
		public static String UPDATE_ALL_FROM_USER="UPDATE User u SET u.firstName=:firstName WHERE userId=:userId";
		public static String UPDATE_ALL_FROM_USERLOGIN="UPDATE UserLogin u SET u.email=:email";
		public static String UPDATE_ALL_FROM_QUESTIONS="UPDATE Questions q SET q.question=:question";
		public static String UPDATE_ALL_FROM_ADMINLOGIN="UPDATE AdminLogin a SET a.password=:password";
		public static String UPDATE_ALL_FROM_EXAM="UPDATE Exam e SET e.examName=:examName";
		public static String UPDATE_ALL_FROM_ADMINEXAM="UPDATE AdminExam a SET a.examId=:examId ";
		public static String UPDATE_ALL_FROM_CACHETABLE="UPDATE CacheTable c SET C.ansSelected=:ansSelected";
		public static String UPDATE_ALL_FROM_USERSCORE="UPDATE UserScore u SET u.scorePerAttemp=:scorePerAttempt" ;
	
	public static void main(String[] args) {
		//AdminLogin admin=new AdminLogin(120,"Anukool","admin");
		//User user= new User(103,"Chandana","Reddy","reddyharichandana@gmail.com","6302949372","30-08-1998","Kurnool","AP","B.TECH",2019);
		//Exam exam=new Exam(201,"java","23-01-2020","06:00","07:00");
		//Questions question =new Questions(4,201,"What is ur name?","Anukool","Chandana","Varsha","Sambit","Chandana");
		/*admin.setAdminId(admin.getAdminId());
		admin.setAdminName(admin.getAdminName());
		admin.setAdminPassword(admin.getAdminPassword());*/
		
//		entityManager = JpaUtils.getEntityManager();
		
		
		//insertAdmins(admin);
		//insertUsers(user);
		//insertExam(exam);
		//insertQuestions(question);
		entityManager = JpaUtils.getEntityManager();
		User user=new User();
		user.setFirstName("Akshay");
		 updateUsers(103,user);
		
	    
	}
	public void readAllAdmin() {
//		entityManager = JpaUtils.getEntityManager();
//		TypedQuery<AdminExam> tquery = entityManager.createQuery(GET_ALL_ADMIN_EXAM,AdminExam.class);
//		List<AdminExam>result=tquery.getResultList();
//		System.out.println(result);
//	}
	}
	
	public void readAllAdminLogin() {
		entityManager = JpaUtils.getEntityManager();
		TypedQuery<AdminLogin> tquery = entityManager.createQuery(GET_ALL_ADMIN_LOGIN,AdminLogin.class);
		List<AdminLogin>result=tquery.getResultList();
		System.out.println(result);
	}
	
	public void readAllCacheTable() {
		entityManager = JpaUtils.getEntityManager();
		TypedQuery<CacheTable> tquery = entityManager.createQuery(GET_ALL_CACHE_TABLE,CacheTable.class);
		List<CacheTable>result=tquery.getResultList();
		System.out.println(result);
	}
	
	
	public void readAllExam() {
		entityManager = JpaUtils.getEntityManager();
		TypedQuery<Exam> tquery = entityManager.createQuery(GET_ALL_EXAM,Exam.class);
		List<Exam>result=tquery.getResultList();
		System.out.println(result);
	}
	
	
	public void readAllQuestions() {
		entityManager = JpaUtils.getEntityManager();
		TypedQuery<Questions> tquery = entityManager.createQuery(GET_ALL_QUESTIONS,Questions.class);
		List<Questions>result=tquery.getResultList();
		System.out.println(result);
	}
	
	
	public void readAllUser() {
		entityManager = JpaUtils.getEntityManager();
		TypedQuery<User> tquery = entityManager.createQuery(GET_ALL_USER,User.class);
		List<User>result=tquery.getResultList();
		System.out.println(result);
	}
	
	
	public void readAllUserLogin() {
		entityManager = JpaUtils.getEntityManager();
		TypedQuery<UserLogin> tquery = entityManager.createQuery(GET_ALL_USER_LOGIN,UserLogin.class);
		List<UserLogin>result=tquery.getResultList();
		System.out.println(result);
	}
	
	public void readAllUserScore() {
		entityManager = JpaUtils.getEntityManager();
		TypedQuery<UserScore> tquery = entityManager.createQuery(GET_ALL_USER_SCORE,UserScore.class);
		List<UserScore>result=tquery.getResultList();
		System.out.println(result);
	}
	
	
	public static void insertAdmins(AdminLogin admin) {
		entityManager = JpaUtils.getEntityManager();
//		Query query = entityManager.createQuery(GET_ADMIN_BY_ADMIN_LOGIN);
//		query.setParameter(1, admin.getAdminId());
//		query.setParameter(2, admin.getAdminName());
//		query.setParameter(3, admin.getAdminPassword());
		entityManager.getTransaction().begin();
		entityManager.persist(admin);
		entityManager.getTransaction().commit();
	}

	public static void insertUsers(User user) {
		entityManager = JpaUtils.getEntityManager();
		/*Query query = entityManager.createQuery(GET_USER_BY_USER_REGISTRATION);
		query.setParameter(1, user.getUserId());
		query.setParameter(2, user.getFirstName());
		query.setParameter(3, user.getLastName());
		query.setParameter(4, user.getEmail());
		query.setParameter(5, user.getMobileNumber());
		query.setParameter(6, user.getDateOfBirth());
		query.setParameter(7, user.getCity());
		query.setParameter(8, user.getState());
		query.setParameter(9, user.getQualification());
		query.setParameter(10, user.getYearOfCompletion());
		query.executeUpdate();*/
		entityManager.getTransaction().begin();
		entityManager.persist(user);
		entityManager.getTransaction().commit();
	}
	
	public static void insertExam(Exam exam) {
		entityManager = JpaUtils.getEntityManager();
		/*Query query = entityManager.createQuery(GET_EXAM_DETAILS);
		query.setParameter(1, exam.getExamId());
		query.setParameter(2, exam.getExamName());
		query.setParameter(3, exam.getExamDate());
		query.setParameter(4, exam.getStartTime());
		query.setParameter(5, exam.getEndTime());
		query.executeUpdate();*/
		entityManager.getTransaction().begin();
		entityManager.persist(exam);
		entityManager.getTransaction().commit();
	}

	public static void insertQuestions(Questions question) {
		entityManager = JpaUtils.getEntityManager();
		/*Query query = entityManager.createQuery(GET_QUESTION_DETAILS);
		query.setParameter(1, question.getQuestionId() );
		query.setParameter(2, question.getQuestion());
		query.setParameter(3, question.getOption1());
		query.setParameter(4, question.getOption2());
		query.setParameter(5, question.getOption3());
		query.setParameter(6, question.getOption4());
		query.setParameter(7, question.getCorrectAnswer());
		query.executeUpdate();*/
		entityManager.getTransaction().begin();
		entityManager.persist(question);
		entityManager.getTransaction().commit();
	}

	
	public void insertUserScore(UserScore userscore) {
		entityManager = JpaUtils.getEntityManager();
		Query query = entityManager.createQuery(GET_EXAM_DETAILS);
		query.setParameter(1, userscore.getUserScoreId());
		query.setParameter(2, userscore.getScorePerAttempt());
		query.setParameter(3, userscore.getDateOfExam());
		query.setParameter(4, userscore.getTimeTaken());
		query.executeUpdate();
	}

	public void insertCacheTable(CacheTable cachetable) {
		entityManager = JpaUtils.getEntityManager();
		/*Query query = entityManager.createQuery(GET_EXAM_DETAILS);
		query.setParameter(1, cachetable.getCacheId());
		query.setParameter(2, cachetable.getAnsSelected());
		query.executeUpdate();*/
	}
	
	 //update
	   public static  void updateUsers(int userId, User users){
		   entityManager=JpaUtils.getEntityManager();
		   Query query=entityManager.createQuery(UPDATE_ALL_FROM_USER);
		   query.setParameter("firstName", users.getFirstName());
		   query.setParameter("userId", userId);
		   entityManager.getTransaction().begin();
		   query.executeUpdate();
		   entityManager.getTransaction().commit();
	   }
	   public void updateUserLogin(int userId){
		   entityManager=JpaUtils.getEntityManager();
		   Query query=entityManager.createQuery(UPDATE_ALL_FROM_USERLOGIN); 
		   entityManager.getTransaction().begin();
		   query.executeUpdate();
		   entityManager.getTransaction().commit();
	   }
	
}
